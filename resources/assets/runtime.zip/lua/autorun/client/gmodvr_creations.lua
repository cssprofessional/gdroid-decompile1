-- The port's HTML panel has no JavaScript engine. Present Sandbox's local
-- creations with Derma, while retaining its dupe transport and save commands.
if not gmodvr or not gmodvr.GetPose then return end

local dupeReady = false
local panels = {}

local function refresh(kind)
    local panel = panels[kind]
    if IsValid(panel) then panel:RefreshFiles() end
end

local function creationPanel(kind)
    local save = kind == "saves"
    local panel = vgui.Create("DPanel")
    panels[kind] = panel
    panel:DockPadding(8, 8, 8, 8)

    local help = panel:Add("DLabel")
    help:Dock(TOP)
    help:SetTall(38)
    help:SetContentAlignment(7)
    help:SetTextColor(Color(60, 60, 60))
    local instructions = save and "Save this map's objects and your player. Select a save and press Load to restore it."
        or "Right-click objects with the Duplicator, then Save dupe. Select a dupe and Arm to paste it."
    help:SetText(instructions)

    local toolbar = panel:Add("DPanel")
    toolbar:Dock(BOTTOM)
    toolbar:SetTall(32)
    toolbar:DockMargin(0, 8, 0, 0)
    toolbar:SetPaintBackground(false)
    local saveButton = toolbar:Add("DButton")
    saveButton:Dock(LEFT)
    saveButton:SetWide(120)
    saveButton:SetText(save and "Save game" or "Save dupe")
    saveButton.DoClick = function()
        if save then RunConsoleCommand("gm_save", "spawnmenu") else RunConsoleCommand("dupe_save") end
    end
    saveButton.Think = function(button)
        local ply = LocalPlayer()
        button:SetEnabled(IsValid(ply) and (save and (game.SinglePlayer() or ply:IsAdmin()) or (not save and dupeReady)))
    end
    local loadButton = toolbar:Add("DButton")
    loadButton:Dock(LEFT)
    loadButton:SetWide(100)
    loadButton:DockMargin(8, 0, 0, 0)
    loadButton:SetText(save and "Load" or "Arm")
    local refreshButton = toolbar:Add("DButton")
    refreshButton:Dock(RIGHT)
    refreshButton:SetWide(100)
    refreshButton:SetText("Refresh")

    local files = panel:Add("DListView")
    files:Dock(FILL)
    files:DockMargin(0, 4, 0, 0)
    files:SetMultiSelect(false)
    files:AddColumn("Name")
    files:AddColumn(save and "Map" or "Source"):SetFixedWidth(160)
    panel.Files = files
    panel.SaveButton = saveButton
    panel.LoadButton = loadButton

    function panel:RefreshFiles()
        files:Clear()
        local found = file.Find(kind .. (save and "/*.gms" or "/*.dupe"), "GAME", "datedesc")
        for _, name in ipairs(found) do
            local path = kind .. "/" .. name
            local info = save and GetSaveFileDetails(path)
            local detail = save and (info and info.map or "Unreadable save") or (file.Exists(path, "MOD") and "Local" or "Installed addon")
            local line = files:AddLine(string.StripExtension(name), detail)
            line.Filename = path
            line.SaveInfo = info
        end
        if #found > 0 then
            help:SetText(instructions)
        else
            help:SetText(save and "No saves yet. Press Save game to save this map's objects and your player."
                or "No dupes yet. Right-click objects with the Duplicator tool, then press Save dupe.")
        end
    end

    local function loadSelected()
        local index = files:GetSelectedLine()
        local line = index and files:GetLine(index)
        if not IsValid(line) then return end
        if save and (not line.SaveInfo or not LocalPlayer():IsListenServerHost()) then return end
        local function load()
            RunConsoleCommand(save and "gm_load" or "dupe_arm", line.Filename)
            if IsValid(g_SpawnMenu) then g_SpawnMenu:Close() end
        end
        if save and line.SaveInfo.map ~= game.GetMap() then
            Derma_Query("This save will change the map to " .. line.SaveInfo.map .. ".", "Load save", "Load", load, "Cancel")
        else
            load()
        end
    end
    loadButton.DoClick = loadSelected
    files.DoDoubleClick = loadSelected
    loadButton.Think = function(button)
        local index = files:GetSelectedLine()
        local line = index and files:GetLine(index)
        local ply = LocalPlayer()
        button:SetEnabled(IsValid(line) and IsValid(ply) and (not save or (line.SaveInfo ~= nil and ply:IsListenServerHost())))
        if save then button:SetTooltip("Only the host can restore a save.") end
    end
    refreshButton.DoClick = function() panel:RefreshFiles() end
    panel:RefreshFiles()
    return panel
end

hook.Add("PostGamemodeLoaded", "GmodVR_CreationTabs", function()
    local tabs = spawnmenu.GetCreationTabs()
    -- Preserve the gamemode's tab ordering, icons and any absence of these tabs.
    if tabs["#spawnmenu.category.dupes"] then
        tabs["#spawnmenu.category.dupes"].Function = function() return creationPanel("dupes") end
    end
    if tabs["#spawnmenu.category.saves"] then
        tabs["#spawnmenu.category.saves"].Function = function() return creationPanel("saves") end
    end
end)
hook.Add("DupeSaveAvailable", "GmodVR_Creations", function() dupeReady = true end)
hook.Add("DupeSaveUnavailable", "GmodVR_Creations", function() dupeReady = false end)
hook.Add("DupeSaved", "GmodVR_Creations", function() refresh("dupes") end)
hook.Add("PostGameSaved", "GmodVR_Creations", function() refresh("saves") end)
hook.Add("OnSpawnMenuOpen", "GmodVR_Creations", function() refresh("dupes") refresh("saves") end)
