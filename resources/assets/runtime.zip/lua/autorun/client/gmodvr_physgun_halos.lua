-- Sandbox adds independent RGB noise to physgun halos, which makes black and
-- dark weapon colours flash other hues. Flicker the brightness instead.
-- Batch native outlines before the scene, retaining stock halos as a fallback.
local targets = {}
local physgunHalo
local nativeFrame = -1
-- Tag only the entries queued by this adaptation. Other addons keep their
-- own halo.Render behaviour and their original position in the halo queue.
local optimization = halo._GModVRPhysgunHaloOptimization or {entries = setmetatable({}, {__mode = "k"})}

local function drawBeam(self, ply, weapon, enabled, target, bone, pos)
    if physgunHalo:GetInt() ~= 0 and IsValid(ply) and IsValid(target) then
        targets[ply] = target
    end
    return true
end

local function buildEntries(pending)
    local entries = {}
    if physgunHalo:GetInt() ~= 0 then
        for ply, target in pairs(pending) do
            if IsValid(ply) and IsValid(target) then
                local color = ply:GetWeaponColor()
                -- An additive black halo contributes nothing to the scene.
                if color.x > 0 or color.y > 0 or color.z > 0 then
                    local brightness = math.Rand(0.7, 1.3) * 255
                    entries[#entries + 1] = {entity = target,
                        color = Color(color.x * brightness, color.y * brightness, color.z * brightness)}
                end
            end
        end
    end
    return entries
end

local function drawHalos()
    if nativeFrame == FrameNumber() then return end
    local pending = targets
    targets = {}
    local entries = buildEntries(pending)
    for _, entry in ipairs(entries) do
        local size = math.random(1, 2)
        local entities = {entry.entity}
        optimization.entries[entities] = true
        halo.Add(entities, entry.color, size, size, 1, true, false)
    end
end

local function installStockOptimization()
    if not render.RenderGModPhysgunHalo or not render.SupportsGModPhysgunHaloOptimization
        or not render.SupportsGModPhysgunHaloOptimization() or not halo.Render then return end
    if halo.Render == optimization.wrapper then return end
    local renderer = halo.Render
    local source = debug.getinfo(renderer, "S").source
    if not source:match("includes/modules/halo%.lua$") or source:match("^@?addons/")
        or source:find("/addons/", 1, true) then return end
    local enabled = GetConVar("gmod_physgun_optimize_halo")
    if not enabled then return end
    local store, blur = render.GetScreenEffectTexture(0), render.GetScreenEffectTexture(1)
    local copy = Material("pp/copy")
    optimization.stockRender = renderer
    optimization.wrapper = function(entry)
        local ours = optimization.entries[entry.Ents]
        optimization.entries[entry.Ents] = nil
        if ours and enabled:GetBool() and entry.Additive and not entry.IgnoreZ and entry.DrawPasses == 1
            and render.RenderGModPhysgunHalo(renderer, entry, store, blur, copy) then return end
        return renderer(entry)
    end
    halo._GModVRPhysgunHaloOptimization = optimization
    halo.Render = optimization.wrapper
end

local function drawNativeHalos()
    if not physgunHalo or not render.SetGModPhysgunHalos then return end
    local hooks = hook.GetTable().PreDrawHalos
    if not hooks or hooks.AddPhysgunHalos ~= drawHalos then return end
    local frame = FrameNumber()
    if nativeFrame == frame then return end
    -- Submit before the scene's native glow pass in both flat and VR views.
    -- PreRender runs once per frame; registrations survive both VR eyes.
    if render.SetGModPhysgunHalos(buildEntries(targets)) then
        targets = {}
        nativeFrame = frame
    end
end

local function install()
    installStockOptimization()
    local sandbox = gamemode.Get("sandbox")
    if not sandbox or not sandbox.DrawPhysgunBeam then return end
    if sandbox.DrawPhysgunBeam == drawBeam then return end

    local stockBeam = sandbox.DrawPhysgunBeam
    local hooks = hook.GetTable().PreDrawHalos
    local stockHalos = hooks and hooks.AddPhysgunHalos
    if not stockHalos then return end
    -- Only replace Sandbox's built-in pair. Keep addon/gamemode overrides.
    local source = debug.getinfo(stockBeam, "S").source
    if not source:match("sandbox/gamemode/cl_init%.lua$") or
        debug.getinfo(stockHalos, "S").source ~= source then return end

    physgunHalo = GetConVar("physgun_halo")
    if not physgunHalo then return end
    targets = {}
    nativeFrame = -1
    sandbox.DrawPhysgunBeam = drawBeam
    local gm = GAMEMODE
    while gm do
        if gm.DrawPhysgunBeam == stockBeam then gm.DrawPhysgunBeam = drawBeam end
        gm = gm.BaseClass
    end
    local base = baseclass.Get("gamemode_sandbox")
    if base.DrawPhysgunBeam == stockBeam then base.DrawPhysgunBeam = drawBeam end
    hook.Add("PreDrawHalos", "AddPhysgunHalos", drawHalos)
end

hook.Add("PostGamemodeLoaded", "gmodvr_physgun_halos", install)
hook.Add("OnReloaded", "gmodvr_physgun_halos", install)
hook.Add("PreRender", "gmodvr_physgun_halos", drawNativeHalos)
hook.Add("PopulateToolMenu", "gmodvr_physgun_halos", function()
    if not GetConVar("gmod_physgun_fast_halo") then return end
    spawnmenu.AddToolMenuOption("Utilities", "User", "GModVRPhysgunHalo", "Physics Gun", "", "", function(panel)
        if render.SupportsGModPhysgunHaloOptimization and render.SupportsGModPhysgunHaloOptimization() then
            panel:CheckBox("Optimize original Physics Gun glow", "gmod_physgun_optimize_halo")
            panel:Help("Experimental optimization that preserves the original blurred glow. On by default; changes take effect immediately. Used when Simplify Physics Gun glow is off.")
        end
        panel:CheckBox("Simplify Physics Gun glow", "gmod_physgun_fast_halo")
        panel:Help("Uses a sharper outline around held objects to reduce rendering cost. Off by default; changes take effect immediately.")
    end)
end)
install()
