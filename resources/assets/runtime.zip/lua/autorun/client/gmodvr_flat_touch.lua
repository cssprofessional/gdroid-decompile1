-- GDroid: touchscreen helpers (runtime overlay, client realm).
--
-- Touch buttons run console commands and Derma takes a single pointer, so
-- holding a "Q" button while tapping the spawn menu with another finger does
-- not work. The spawn and context menus are therefore toggled by a tap
-- (the touch layout binds gmod_touch_spawnmenu / gmod_touch_contextmenu);
-- keyboards keep Valve's hold-to-open +menu / +menu_context.

local function IsOpen( panel )
	return IsValid( panel ) and panel:IsVisible()
end

local function Toggle( panel, openHook, closeHook )
	if IsOpen( panel ) then
		hook.Run( closeHook )
	else
		hook.Run( openHook )
	end
end

-- Touch buttons whose command is a key bind (+reload, impulse 100, invnext,
-- ...) press the key bound to it (game/client/gmod/gmod_touch_keys.cpp), so
-- GM:PlayerBindPress, input.IsKeyDown and PlayerButtonDown see a keyboard.
-- The Lua buttons below (menus, toggles) do the same by hand: a press goes to
-- GM:PlayerBindPress first, and a hook that returns true takes it instead of
-- the command -- whatever takes the key over gets it (ARC9 opens and closes
-- its customize screen on C, cycles attachments on Tab there). A taken press
-- is released like a key the client trapped (PlayerBindPress with pressed =
-- false) once two user commands carried it (ARC9 holds IN_WEAPON1 until the
-- release). A momentary command tap ("+zoom" for a weapon that switches fire
-- modes on it) is let go the same way.
local taps = {}

local function TapPending( bind )
	for _, tap in ipairs( taps ) do
		if ( tap.bind == bind ) then return true end
	end
	return false
end

local function BindTapPress( bind )
	local ply = LocalPlayer()
	if ( !IsValid( ply ) ) then return false end
	local key = input.LookupBinding( bind )
	local code = key and input.GetKeyCode( key ) or 0
	if ( !hook.Run( "PlayerBindPress", ply, bind, true, code ) ) then return false end
	taps[#taps + 1] = { bind = bind, code = code, cmds = 0, t = RealTime() }
	return true
end

local function CommandTap( bind )
	RunConsoleCommand( bind )
	taps[#taps + 1] = { bind = bind, run = true, cmds = 0, t = RealTime() }
end

hook.Add( "CreateMove", "gmodvr_flat_touch_bindtap", function( cmd )
	if ( cmd:CommandNumber() == 0 ) then return end
	for _, tap in ipairs( taps ) do tap.cmds = tap.cmds + 1 end
end )

hook.Add( "Think", "gmodvr_flat_touch_bindtap", function()
	if ( #taps == 0 ) then return end
	local now = RealTime()
	for i = #taps, 1, -1 do
		local tap = taps[i]
		local held = now - tap.t
		if ( ( tap.cmds >= 2 and held >= 0.1 ) or held >= 1 ) then
			table.remove( taps, i )
			if ( tap.run ) then
				RunConsoleCommand( "-" .. string.sub( tap.bind, 2 ) )
			else
				local ply = LocalPlayer()
				if ( IsValid( ply ) ) then hook.Run( "PlayerBindPress", ply, tap.bind, false, tap.code ) end
			end
		end
	end
end )

concommand.Add( "gmod_touch_spawnmenu", function()
	if ( TapPending( "+menu" ) ) then return end
	if IsOpen( g_ContextMenu ) then hook.Run( "OnContextMenuClose" ) end
	if ( !IsOpen( g_SpawnMenu ) and BindTapPress( "+menu" ) ) then return end
	Toggle( g_SpawnMenu, "OnSpawnMenuOpen", "OnSpawnMenuClose" )
end, nil, "Touch: open or close the spawn menu (Q)." )

concommand.Add( "gmod_touch_contextmenu", function()
	if ( TapPending( "+menu_context" ) ) then return end
	if IsOpen( g_SpawnMenu ) then hook.Run( "OnSpawnMenuClose" ) end
	if ( !IsOpen( g_ContextMenu ) and BindTapPress( "+menu_context" ) ) then return end
	Toggle( g_ContextMenu, "OnContextMenuOpen", "OnContextMenuClose" )
end, nil, "Touch: open or close the context menu (C)." )

-- Tap-to-toggle versions of held buttons (a held touch button keeps a finger
-- busy). Each toggle is a Lua command rather than a console alias, so it
-- survives the touch editor rewriting touch.cfg. A press a PlayerBindPress
-- hook takes is a tap, not a latch (a latched key would need a second tap
-- before the next press). `momentary` (optional) returns true while a tap
-- should press and release at once instead of latching; a latch it finds
-- held is let go.
local function HoldToggle( name, command, help, momentary )
	local bind = "+" .. command
	local held = false
	concommand.Add( name, function()
		if ( held ) then
			held = false
			RunConsoleCommand( "-" .. command )
			return
		end
		if ( TapPending( bind ) ) then return end
		if ( BindTapPress( bind ) ) then return end
		if ( momentary and momentary() ) then
			CommandTap( bind )
			return
		end
		held = true
		RunConsoleCommand( bind )
	end, nil, help )
	hook.Add( "InitPostEntity", name, function() held = false end )
	if ( momentary ) then
		hook.Add( "Think", name, function()
			if ( held and momentary() ) then
				held = false
				RunConsoleCommand( "-" .. command )
			end
		end )
	end
end

-- The crouch button (+gmod_touch_duck): a short tap toggles crouching as
-- before, holding it crouches until it is let go. Gamemodes that act on each
-- crouch press (Beatrun's slide, crouch jump and safety roll read
-- KeyPressed( IN_DUCK )) only got a press on every second tap of a latch.
-- gmod_touch_duck_tap 0 makes the button hold-only, a large value tap-only.
-- "gmod_touch_duck" (press only; layouts saved before 0.1.12 until touch.cpp
-- migrates them) is the tap toggle and shares the latch.
local duckTap = CreateClientConVar( "gmod_touch_duck_tap", "0.25", true, false,
	"Touch: a crouch button press shorter than this (seconds) toggles crouching; a longer one crouches while held. 0 = hold only." )
local duckLatched, duckDownAt, duckUnlatched = false, nil, false

local function DuckPress()
	if ( duckLatched ) then
		duckLatched = false
		duckUnlatched = true
		RunConsoleCommand( "-duck" )
		return false
	end
	duckUnlatched = false
	duckDownAt = nil
	if ( TapPending( "+duck" ) or BindTapPress( "+duck" ) ) then return false end
	RunConsoleCommand( "+duck" )
	duckDownAt = RealTime()
	return true
end

concommand.Add( "+gmod_touch_duck", function() DuckPress() end, nil,
	"Touch: crouch while held; a short tap toggles crouching (gmod_touch_duck_tap)." )
concommand.Add( "-gmod_touch_duck", function()
	if ( duckUnlatched ) then duckUnlatched = false return end
	if ( !duckDownAt ) then return end
	local held = RealTime() - duckDownAt
	duckDownAt = nil
	if ( held < duckTap:GetFloat() ) then
		duckLatched = true
		return
	end
	RunConsoleCommand( "-duck" )
end, nil, "Touch: crouch button released." )
concommand.Add( "gmod_touch_duck", function()
	if ( DuckPress() ) then
		duckDownAt = nil
		duckLatched = true
	end
end, nil, "Touch: toggle crouching." )
hook.Add( "InitPostEntity", "gmod_touch_duck", function()
	duckLatched, duckDownAt, duckUnlatched = false, nil, false
end )
HoldToggle( "gmod_touch_scoreboard", "showscores", "Touch: toggle the scoreboard." )
-- Suit zoom is hold-to-zoom; a quick tap could press and release in one frame
-- and never zoom, so the touch button toggles it instead. Without suit zoom
-- (Player:SetCanZoom( false ): weapons that use the zoom key themselves, such
-- as ARC9's fire mode switch, or E + zoom for its safety) each tap is one
-- press of the key.
HoldToggle( "gmod_touch_zoom", "zoom", "Touch: toggle the suit zoom (a tap of +zoom without suit zoom).", function()
	local ply = LocalPlayer()
	return IsValid( ply ) and !ply:GetCanZoom()
end )
-- Layouts saved by 0.1.1 and earlier bound the zoom button to "+zoom" (hold).
hook.Add( "InitPostEntity", "gmodvr_flat_touch_zoom", function()
	RunConsoleCommand( "touch_setcommand", "zoom", "gmod_touch_zoom" )
end )

-- The "more" button shows the hidden top-row buttons of touch_default.cfg.
local MoreButtons = { "cleanup", "thirdperson", "console", "kill" }
local moreOpen = false

concommand.Add( "gmod_touch_more", function()
	moreOpen = not moreOpen
	for _, name in ipairs( MoreButtons ) do
		RunConsoleCommand( moreOpen and "touch_show" or "touch_hide", name )
	end
	RunConsoleCommand( "touch_settexture", "more", moreOpen and "vgui/touch/sb_xg" or "vgui/touch/sb_menuplus" )
end, nil, "Touch: show or hide the extra top-row buttons." )

-- While the spawn or context menu is open the buttons would cover its panels
-- (the tool settings sit under the right thumb), so the menu toggles and a
-- separate spawn-menu movement pad stay up. Names are those of touch_default.cfg; the
-- launcher's custom key buttons (custom_*) go with them (touch_custom_hide
-- also lets go of a key held by one), except while a tool's "press a key"
-- prompt is waiting for one of those buttons.
local MenuHidden = {
	"move", "more", "edit", "undo", "speed", "invprev", "lastinv", "invnext", "pause",
	"zoom", "chat", "score", "voice", "wheelup", "noclip", "wheeldown", "use",
	"flashlight", "attack2", "reload", "attack", "jump", "duck",
	"cleanup", "thirdperson", "console", "kill",
}
-- Any other screen that takes the pointer (gui.EnableScreenClicker or a
-- popup: a weapon base's customize screen such as ARC9's, an addon window,
-- the chat box) gets the same treatment: the gameplay buttons sat on its
-- controls and took the finger (a tap on an ARC9 attachment over the weapon
-- arrows switched weapons). The scoreboard / chat toggles stay, and so do the
-- custom key buttons: they are how such screens are closed (ARC9: C).
local PointerKept = { score = true, chat = true }
-- The spawn-menu toggle covers the top-right close button of addon screens.
-- Keep it for the spawn/context menus, but let other screens take that space.
local PointerHidden = { "spawnmenu" }
for _, name in ipairs( MenuHidden ) do
	if ( !PointerKept[name] ) then PointerHidden[#PointerHidden + 1] = name end
end
-- touch_ui_hide / touch_ui_show (game/client/touch.cpp) leave the buttons'
-- own hidden flags alone (a button hidden in the editor, the "more" row) and
-- are never saved.
local HiddenFor = { menu = MenuHidden, binding = MenuHidden, pointer = PointerHidden }
local uiMode = nil

-- The context menu's desktop widgets (Player Model, ...) are a column at the
-- left edge, in no fixed order, exactly where the spawn / context menu
-- buttons stay up: a widget under one could not be tapped (the button took
-- the finger). Start the column right of the touch buttons.
local widgetMargin = CreateClientConVar( "gmod_touch_widget_margin", "0.09", true, false,
	"Touch: left margin of the context menu's desktop widgets, as a fraction of the screen width." )

local function PlaceDesktopWidgets()
	local layout = IsValid( g_ContextMenu ) and g_ContextMenu.DesktopWidgets
	if ( !IsValid( layout ) ) then return end
	local margin = math.floor( ScrW() * math.Clamp( widgetMargin:GetFloat(), 0, 0.5 ) )
	if ( layout.gmodvrMargin == margin ) then return end
	layout.gmodvrMargin = margin
	layout:DockMargin( margin, 0, 0, 0 )
	layout:InvalidateParent( true )
end

-- Reserve a narrow strip beside the spawn list for a native movement pad.
-- The ordinary move zone covers the spawn list itself; allowing it while
-- the cursor is visible would turn prop clicks into movement touches.
local function MenuMoveRect()
	local w, h = ScrW(), ScrH()
	local size = math.min( h * 0.22, w * 0.12 )
	local x1, y2 = 12 / w, 0.94
	return x1, y2 - size / h, x1 + size / w, y2
end

local function PlaceSpawnMenuMovement()
	local menu = g_SpawnMenu
	if ( !IsValid( menu ) or menu.gmodvrMoveLayout ) then return end
	local layout = menu.PerformLayout
	menu.gmodvrMoveLayout = true
	menu.PerformLayout = function( self, ... )
		layout( self, ... )
		if ( !IsValid( self.HorizontalDivider ) ) then return end
		local _, _, right = MenuMoveRect()
		local left, top, r, bottom = self.HorizontalDivider:GetDockMargin()
		self.HorizontalDivider:DockMargin( math.max( left, math.ceil( right * ScrW() ) + 12 ), top, r, bottom )
	end
	menu:InvalidateLayout( true )
end

local menuMoveState = nil
local function UpdateMenuMovement( mode )
	local enabled = mode == "menu" and IsOpen( g_SpawnMenu ) and
		!g_SpawnMenu:IsKeyboardInputEnabled() and !IsValid( vgui.GetKeyboardFocus() ) and
		!gui.IsGameUIVisible()
	if ( IsOpen( g_SpawnMenu ) ) then PlaceSpawnMenuMovement() end
	local state = enabled and ( ScrW() .. "x" .. ScrH() ) or false
	if ( state == menuMoveState ) then return end
	menuMoveState = state
	if ( enabled ) then
		local x1, y1, x2, y2 = MenuMoveRect()
		RunConsoleCommand( "touch_menu_move", "1", tostring( x1 ), tostring( y1 ), tostring( x2 ), tostring( y2 ) )
	else
		RunConsoleCommand( "touch_menu_move", "0" )
	end
end

local function SetUIMode( mode )
	local old = uiMode
	uiMode = mode
	local hide = HiddenFor[mode] or {}
	local want = {}
	for _, name in ipairs( hide ) do want[name] = true end
	local show = {}
	for _, name in ipairs( HiddenFor[old] or {} ) do
		if ( !want[name] ) then show[#show + 1] = name end
	end
	if ( #show > 0 ) then RunConsoleCommand( "touch_ui_show", unpack( show ) ) end
	if ( #hide > 0 ) then RunConsoleCommand( "touch_ui_hide", unpack( hide ) ) end
	if ( ( old == "menu" ) != ( mode == "menu" ) ) then
		RunConsoleCommand( mode == "menu" and "touch_custom_hide" or "touch_custom_show" )
	end
end

hook.Add( "Think", "gmodvr_flat_touch_menus", function()
	local mode = nil
	if ( IsOpen( g_SpawnMenu ) or IsOpen( g_ContextMenu ) ) then
		-- Read the capture state without consuming the key the binder needs.
		mode = input.IsKeyTrapping() and "binding" or "menu"
	elseif ( vgui.CursorVisible() ) then
		mode = "pointer"
	end
	UpdateMenuMovement( mode )
	if ( mode == uiMode ) then return end
	if ( mode == "menu" or mode == "binding" ) then PlaceDesktopWidgets() end
	SetUIMode( mode )
end )

-- A level load can rebuild the buttons (flags cleared): start over.
hook.Add( "InitPostEntity", "gmodvr_flat_touch_menus", function()
	RunConsoleCommand( "touch_ui_show", "spawnmenu", unpack( MenuHidden ) )
	if ( uiMode == "menu" ) then RunConsoleCommand( "touch_custom_show" ) end
	uiMode = nil
	menuMoveState = nil
	RunConsoleCommand( "touch_menu_move", "0" )
end )

-- Third person without sv_cheats (Valve's `thirdperson` is a cheat command):
-- a camera behind the player, pulled in when it would clip into the world.
local thirdPerson = false
local thirdPersonCalcView = false

concommand.Add( "gmod_touch_thirdperson", function()
	thirdPerson = not thirdPerson
end, nil, "Touch: toggle the third-person camera." )

hook.Add( "CalcView", "gmodvr_flat_thirdperson", function( ply, origin, angles, fov, znear, zfar )
	if ( thirdPersonCalcView or !thirdPerson or !ply:Alive() or ply:InVehicle() or ply:GetViewEntity() != ply ) then return end

	local tr = util.TraceHull( {
		start = origin,
		endpos = origin - angles:Forward() * 100 + angles:Right() * 20,
		filter = ply,
		mins = Vector( -4, -4, -4 ),
		maxs = Vector( 4, 4, 4 ),
	} )

	-- Let the gamemode and other camera hooks see the detached camera before
	-- rendering. Beatrun uses this position to hide its first-person body;
	-- returning immediately leaves that headless body drawn over the player.
	-- The guard also covers gamemodes which call CalcView recursively.
	thirdPersonCalcView = true
	local ok, view = pcall( hook.Run, "CalcView", ply, tr.HitPos, angles, fov, znear, zfar )
	thirdPersonCalcView = false
	if ( !ok ) then error( view, 0 ) end
	view = istable( view ) and view or {}
	view.origin = view.origin or tr.HitPos
	view.angles = view.angles or angles
	view.fov = view.fov or fov
	view.drawviewer = true
	return view
end )
