-- The Workshop Charger stops its base velocity at impact, but its local
-- velocity can still carry the animated victim into the wall. Keep the
-- original attack/cleanup code and make the stop and release positions clear.
local classes = {
    npc_vj_l4d2_charger = true,
    npc_vj_l4d2_charger_elite = true,
}
local tag = "GModVR_L4DCharger"

local function heldVictim(charger)
    local victim = charger.pIncapacitatedEnemy
    return IsValid(victim) and victim or nil
end

local function bounds(victim)
    if victim:IsPlayer() then return victim:GetHull() end
    return victim:OBBMins(), victim:OBBMaxs()
end

local function helpers(charger, victim)
    local filter = {charger, victim}
    -- The visible survivor is a separate bonemerged child of the animation
    -- helper. Neither helper should obstruct its own placement trace.
    local function children(parent)
        for _, child in ipairs(parent:GetChildren()) do
            filter[#filter + 1] = child
            children(child)
        end
    end
    children(charger)
    return filter
end

local function hullTrace(pos, dest, mins, maxs, filter)
    return util.TraceHull({start = pos, endpos = dest, mins = mins, maxs = maxs,
        mask = MASK_PLAYERSOLID, filter = filter})
end

local function clear(pos, mins, maxs, filter)
    local tr = hullTrace(pos, pos, mins, maxs, filter)
    return not tr.StartSolid and not tr.AllSolid and not tr.Hit
end

local function stopCarry(charger, victim)
    local state = charger.GModVR_ChargerState
    local forward = (charger.ChargeAngles or charger:GetAngles()):Forward()
    local vmins, vmaxs = bounds(victim)
    local nmins, nmaxs = charger:OBBMins(), charger:OBBMaxs()
    -- Reserve the carried body's offset and width as well as the NPC hull.
    -- The pummel animation extends beyond the invisible player's origin.
    local offset = forward * 64
    local mins, maxs = Vector(), Vector()
    for axis = 1, 3 do
        mins[axis] = math.min(nmins[axis], vmins[axis] + offset[axis])
        maxs[axis] = math.max(nmaxs[axis], vmaxs[axis] + offset[axis])
    end
    local pos = charger:GetPos()
    local filter = helpers(charger, victim)
    local start = state and state.chargeOrigin
    if start and clear(start, mins, maxs, filter) then
        local tr = hullTrace(start, pos, mins, maxs, filter)
        if tr.Hit and not tr.StartSolid then pos = tr.HitPos - forward * 2 end
    elseif not clear(pos, mins, maxs, filter) then
        -- A Charger can grab beside a wall without an earlier charge origin.
        -- Walk back out on the same side; never accept a point beyond a wall.
        local tr = hullTrace(pos, pos - forward * 192, mins, maxs, filter)
        if not tr.AllSolid and tr.FractionLeftSolid > 0 and tr.FractionLeftSolid < 1 then
            local candidate = pos - forward * (192 * tr.FractionLeftSolid + 2)
            if clear(candidate, mins, maxs, filter) then pos = candidate end
        end
    end
    charger:SetVelocity(vector_origin)
    charger:SetLocalVelocity(vector_origin)
    charger:SetPos(pos)
end

local function releasePosition(charger, victim)
    local mins, maxs = bounds(victim)
    local forward = (charger.ChargeAngles or charger:GetAngles()):Forward()
    local pos = charger:GetPos() + Vector(0, 0, 2)
    local filter = helpers(charger, victim)
    local state = charger.GModVR_ChargerState or {}
    -- Sweep away from the impact before restoring collisions. The destination
    -- must also fit with the Charger included, so a survivor can walk away.
    -- The elite's proximity fallback otherwise grabs a released player again.
    local distance = math.max(64, (tonumber(charger.L4D2SI_V11_DirectGrabRange) or 0) + 32)
    for _, distance in ipairs({distance, distance + 32, distance + 64}) do
        local tr = hullTrace(pos, pos - forward * distance, mins, maxs, filter)
        if not tr.StartSolid and not tr.AllSolid and clear(tr.HitPos, mins, maxs, {victim}) then
            return tr.HitPos
        end
    end
    for _, candidate in pairs({state.chargeOrigin, state.victimOrigin}) do
        if candidate and clear(candidate, mins, maxs, {victim}) then return candidate end
    end
    return nil
end

local function install(charger)
    if not IsValid(charger) or not classes[charger:GetClass()] or charger.GModVR_ChargerState then return end
    local charge, grab = charger.ChargeAttack, charger.PummelEnemy
    local setup, dismount = charger.SetUpCharger, charger.DismountCharger
    if not (charge and grab and setup and dismount) then return end
    local state = {}
    charger.GModVR_ChargerState = state
    charger.ChargeAttack = function(self, ...)
        state.chargeOrigin = self:GetPos()
        return charge(self, ...)
    end
    charger.PummelEnemy = function(self, victim, ...)
        if IsValid(victim) and not self.HasEnemyIncapacitated then
            state.victimOrigin = victim:GetPos()
            state.releasedVictim, state.releasePos = nil, nil
        end
        return grab(self, victim, ...)
    end
    charger.SetUpCharger = function(self, ...)
        local victim = heldVictim(self)
        -- The carry timeout clears IsCarryingEnemy before calling this method.
        if victim then stopCarry(self, victim) end
        return setup(self, ...)
    end
    charger.DismountCharger = function(self, ...)
        local victim = heldVictim(self)
        local pos = victim and releasePosition(self, victim)
        if pos then state.releasedVictim, state.releasePos = victim, pos end
        local result = dismount(self, ...)
        if pos and IsValid(victim) and not IsValid(victim:GetParent()) then
            victim:SetPos(pos)
            victim:SetVelocity(vector_origin)
            victim:SetLocalVelocity(vector_origin)
        end
        state.chargeOrigin, state.victimOrigin = nil, nil
        return result
    end
end

local wrappedSafePosition
local function installSafePosition()
    local original = L4D2SI_V14_GetHeldVictimSafePos
    if not original or original == wrappedSafePosition then return end
    wrappedSafePosition = function(victim, data)
        local charger = data and data.attacker
        if IsValid(victim) and IsValid(charger) and classes[charger:GetClass()] and charger.GModVR_ChargerState then
            local state = charger.GModVR_ChargerState
            if state.releasedVictim == victim and state.releasePos then return state.releasePos end
            local pos = releasePosition(charger, victim)
            if pos then return pos end
        end
        return original(victim, data)
    end
    -- The addon calls this before lethal damage and before corpse creation.
    L4D2SI_V14_GetHeldVictimSafePos = wrappedSafePosition
end

hook.Add("OnEntityCreated", tag, function(ent)
    timer.Simple(0, function() install(ent) end)
end)
hook.Add("InitPostEntity", tag, function()
    installSafePosition()
    for class in pairs(classes) do
        for _, ent in ipairs(ents.FindByClass(class)) do install(ent) end
    end
end)
hook.Add("PostGamemodeLoaded", tag, installSafePosition)
