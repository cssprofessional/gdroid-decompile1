-- The 2021 DOOM Eternal NPCs use a reset timer that VJ 3 no longer seeds.
-- Initialize that timer before their existing spawn callback runs.
local classes = {
    npc_vj_tentacle = true,
    npc_vj_gianttentacle = true,
    npc_vj_turret = true,
}

local function install(definition, class)
    if not classes[class] or definition.GModVR_DoomResetTimer then return end
    local initialize = definition.CustomOnInitialize
    if not isfunction(initialize) then return end
    definition.GModVR_DoomResetTimer = true
    definition.CustomOnInitialize = function(self, ...)
        if self.NextResetEnemyT == nil then self.NextResetEnemyT = CurTime() end
        return initialize(self, ...)
    end
end

hook.Add("PreRegisterSENT", "GModVR_DoomResetTimer", install)
-- Also support loading this compatibility file after the addon was loaded.
for class in pairs(classes) do
    local stored = scripted_ents.GetStored(class)
    if stored then install(stored.t, class) end
end
