-- Lambda's Workshop version initializes proplist.json only on the server,
-- then reads it in both realms. A fresh remote client has no private copy.
if SERVER then AddCSLuaFile() return end

hook.Add( "LambdaOnModulesLoaded", "GModVR_LambdaClientProps", function()
	local fs = LAMBDAFS
	if not fs or not isfunction( fs.GetPropTable ) or fs.GModVRClientProps then return end
	fs.GModVRClientProps = true
	local original = fs.GetPropTable
	function fs:GetPropTable( ... )
		if self:ReadFile( "lambdaplayers/proplist.json", "json" ) ~= nil then return original( self, ... ) end
		local defaults = self:ReadFile( "materials/lambdaplayers/data/props.vmt", "json", "GAME" )
		return istable( defaults ) and defaults or {}
	end
end )
