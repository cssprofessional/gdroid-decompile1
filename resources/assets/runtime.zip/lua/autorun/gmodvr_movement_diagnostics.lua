-- Include movement state in exported logs when input is held but the player
-- stays still. A manual report also helps diagnose touch focus and cameras.
if SERVER then
    AddCSLuaFile()
    util.AddNetworkString("gmodvr_movement_report")
end

local states = setmetatable({}, {__mode = "k"})
local viewOrigin
if CLIENT then
    hook.Add("RenderScene", "gmodvr_movement_diagnostics", function(origin)
        viewOrigin = Vector(origin.x, origin.y, origin.z)
    end)
end
local function stateFor(ply)
    local state = states[ply]
    if not state then
        state = {commands = 0, lastReport = -30}
        states[ply] = state
    end
    return state
end

local function command(ply, cmd)
    if not IsValid(ply) then return end
    local state = stateFor(ply)
    state.commandTime = CurTime()
    state.forward, state.side, state.buttons = cmd:GetForwardMove(), cmd:GetSideMove(), cmd:GetButtons()
    if math.abs(state.forward) + math.abs(state.side) > 20 then
        state.commands = state.commands + 1
    end
end

if SERVER then
    hook.Add("StartCommand", "gmodvr_movement_diagnostics", command)
else
    hook.Add("CreateMove", "gmodvr_movement_diagnostics", function(cmd) command(LocalPlayer(), cmd) end)
end

hook.Add("Move", "gmodvr_movement_diagnostics", function(ply, mv)
    local state = stateFor(ply)
    state.moveTime = CurTime()
    state.moveForward, state.moveSide = mv:GetForwardSpeed(), mv:GetSideSpeed()
    state.maxSpeed, state.maxClientSpeed = mv:GetMaxSpeed(), mv:GetMaxClientSpeed()
end)

local function report(ply, reason)
    if not IsValid(ply) then return end
    local state = stateFor(ply)
    local tr = util.TraceEntity({start = ply:GetPos(), endpos = ply:GetPos(), filter = ply}, ply)
    local angles = Angle(0, ply:EyeAngles().y, 0)
    local direction = angles:Forward() * (state.forward or 0) + angles:Right() * (state.side or 0)
    direction:Normalize()
    local ahead = util.TraceEntity({start = ply:GetPos(), endpos = ply:GetPos() + direction * 32, filter = ply}, ply)
    local detail = {
        reason = reason, realm = SERVER and "server" or "client", time = CurTime(),
        map = game.GetMap(), position = ply:GetPos(), velocity = ply:GetVelocity(),
        flags = ply:GetFlags(), moveType = ply:GetMoveType(), observerMode = ply:GetObserverMode(),
        alive = ply:Alive(), onGround = ply:OnGround(), inVehicle = ply:InVehicle(),
        walkSpeed = ply:GetWalkSpeed(), runSpeed = ply:GetRunSpeed(),
        commands = state.commands, forward = state.forward, side = state.side, buttons = state.buttons,
        commandAge = state.commandTime and CurTime() - state.commandTime,
        moveAge = state.moveTime and CurTime() - state.moveTime,
        moveForward = state.moveForward, moveSide = state.moveSide,
        maxSpeed = state.maxSpeed, maxClientSpeed = state.maxClientSpeed,
        stuck = tr.StartSolid, blocker = IsValid(tr.Entity) and tr.Entity:GetClass() or tostring(tr.Entity),
        aheadBlocked = ahead.Hit, aheadBlocker = IsValid(ahead.Entity) and ahead.Entity:GetClass() or tostring(ahead.Entity),
        bonMovementUntil = ply:GetNWInt("DisableMovement_jumpscare_pill_bon_withered"),
    }
    local camera, pill
    if CLIENT then
        camera = {realm = "client", time = detail.time, cursorVisible = vgui.CursorVisible(),
            gameUIVisible = gui.IsGameUIVisible(), drawLocalPlayer = ply:ShouldDrawLocalPlayer(),
            viewEntity = tostring(ply:GetViewEntity()), position = viewOrigin}
    end
    local costume = pk_pills and pk_pills.getMappedEnt(ply)
    local puppet = IsValid(costume) and costume.GetPuppet and costume:GetPuppet()
    if IsValid(puppet) then
        pill = {realm = detail.realm, time = detail.time, puppet = puppet:GetClass(),
            position = puppet:GetPos(), solid = puppet:GetSolid(), moveType = puppet:GetMoveType(),
            sequence = puppet:GetSequenceName(puppet:GetSequence()), cycle = puppet:GetCycle()}
        if CLIENT then pill.renderOrigin = puppet:GetRenderOrigin() end
    end
    print("[GDroid movement] " .. util.TableToJSON(detail))
    -- Keep individual messages below Android's engine log line limit.
    if camera then print("[GDroid movement camera] " .. util.TableToJSON(camera)) end
    if pill then print("[GDroid movement pill] " .. util.TableToJSON(pill)) end
    state.lastReport = CurTime()
end

timer.Create("gmodvr_movement_diagnostics", 1, 0, function()
    for ply, state in pairs(states) do
        if not IsValid(ply) then
            states[ply] = nil
        else
            local position = ply:GetPos()
            local blocked = state.position and (position - state.position):Length2D() < 1 and
                state.commands >= 10 and ply:Alive() and ply:GetMoveType() == MOVETYPE_WALK
            state.blocked = blocked and (state.blocked or 0) + 1 or 0
            -- FL_FROZEN clears server input before StartCommand. Report it
            -- directly so a freeze is visible even when the command is zero.
            local frozen = ply:Alive() and bit.band(ply:GetFlags(), FL_FROZEN) ~= 0
            if CurTime() - state.lastReport >= 10 then
                if frozen then report(ply, "player_frozen")
                elseif state.blocked >= 2 then report(ply, "input_without_movement") end
            end
            state.position, state.commands = position, 0
        end
    end
end)

if SERVER then
    net.Receive("gmodvr_movement_report", function(_, ply)
        if CurTime() - stateFor(ply).lastReport >= 1 then report(ply, "requested") end
    end)
else
    concommand.Add("gmodvr_movement_report", function()
        -- Allow the console to close before checking touch focus and input.
        print("[GDroid movement] report in 2 seconds; close the console and try moving.")
        timer.Simple(2, function()
            report(LocalPlayer(), "requested")
            net.Start("gmodvr_movement_report")
            net.SendToServer()
        end)
    end, nil, "After 2 seconds, log input, collision, touch focus and pill movement state.")
end
