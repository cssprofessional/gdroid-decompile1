-- GDroid: optional walk animation at normal speed (launcher toggle
-- "Walking animation when not sprinting" -> gmodvr_walk_anim, native convar).
-- Garry's Mod's base gamemode picks ACT_MP_RUN above 150 u/s, so normal
-- walking (200 u/s) shows the run animation; with the toggle on, players
-- moving no faster than their walk speed use ACT_MP_WALK instead.
-- Wraps the gamemode's own CalcMainActivity, so CalcMainActivity hooks from
-- addons keep priority (they run before the gamemode function).

local cvar = GetConVar( "gmodvr_walk_anim" )
if ( !cvar ) then return end

local function Wrap()
	local gm = GAMEMODE or GM
	if ( !gm or !gm.CalcMainActivity or gm.GModVRWalkAnimWrapped ) then return end
	local original = gm.CalcMainActivity
	gm.GModVRWalkAnimWrapped = true
	gm.CalcMainActivity = function( self, ply, velocity )
		local ideal, seq = original( self, ply, velocity )
		if ( ideal == ACT_MP_RUN and cvar:GetBool() and IsValid( ply ) ) then
			local walk = ply.GetWalkSpeed and ply:GetWalkSpeed() or 200
			if ( velocity:Length2D() <= walk * 1.1 ) then
				ideal = ACT_MP_WALK
				ply.CalcIdeal = ideal
			end
		end
		return ideal, seq
	end
end

hook.Add( "PostGamemodeLoaded", "GModVRWalkAnim", Wrap )
hook.Add( "Initialize", "GModVRWalkAnim", Wrap )
Wrap()
