# Fallback fonts — plan §B.8.4

**These ship in no retail HL2 tree.** The Android font branch is keyed off
`cl_language`, so this directory supplies the freely redistributable faces the
port needs in addition to the user's Valve content.

All seven faces are staged into the APK and its verified overlay before native
startup. `linuxfont.cpp` loads CJK/Thai directly from lower-case paths under
`vr_overlay/fonts/`, and the Latin/mono faces from lower-case paths under
`platform/resource/linux_fonts/`. This is intentionally eager: `EngineVGui`
loads `SourceScheme.res` before the client DLL exists, so a clean Korean launch
cannot wait for `CVRL10nSystem` to copy a font into `$APP_DATA_PATH/files/`.
That later, language-selective copy remains only as a compatibility/diagnostic
cache and is not part of the startup contract.

| File | Covers | Requested when `cl_language` is | Licence | Bytes |
|---|---|---|---|---|
| `DejaVuSans.ttf` | Latin, Latin Ext, Cyrillic, Greek | anything not listed below (the default branch) | DejaVu (Bitstream Vera derivative, permissive) | 757,076 |
| `DejaVuSans-Bold.ttf` | as above | as above | DejaVu | 705,684 |
| `DejaVuSans-Oblique.ttf` | as above | as above | DejaVu | 635,416 |
| `DejaVuSans-BoldOblique.ttf` | as above | as above | DejaVu | 643,292 |
| `LiberationMono-Regular.ttf` | Latin monospace | requested face is `"Courier New"` | SIL OFL 1.1 | 319,508 |
| `DroidSansFallback.ttf` | CJK — Han, Hiragana, Katakana, Hangul | `japanese` `koreana` `korean` `tchinese` `schinese` | Apache-2.0 | 3,451,900 |
| `Itim-Regular.ttf` | Thai | `thai` | SIL OFL 1.1 | 371,384 |

The seven unique face files total **6.88 MB**. The extracted overlay also keeps
the five Latin/mono faces in their historical PLATFORM layout, adding a 3.06 MB
duplicate so every scheme path is available before startup. The optional cache
can add at most another 6.51 MB for a CJK player (the default Latin/mono set plus
DroidSansFallback), but rendering never depends on that cache.

The plan's UNVERIFIED size estimates were DejaVu ~2.5 MB, DroidSansFallback
~4.5 MB, Itim ~0.2 MB, LiberationMono ~0.3 MB.  Measured: 2.74 / 3.45 / 0.37 /
0.32 MB.  DroidSansFallback is **1.05 MB smaller** than budgeted and Itim is
0.17 MB larger; the net is 0.9 MB under.

## Coverage against HL2's 28 shipped caption databases

The retail tree ships `closecaption_<lang>.dat` for: brazilian, bulgarian,
czech, danish, dutch, english, finnish, french, german, greek, hungarian,
italian, japanese, korean, koreana, latam, norwegian, polish, portuguese,
romanian, russian, schinese, spanish, swedish, tchinese, thai, turkish,
ukrainian.

- **23 of 28** are Latin, Cyrillic or Greek → DejaVu Sans.  (Bulgarian, Russian
  and Ukrainian are the Cyrillic three; Greek is Greek; the rest are Latin,
  including Czech, Hungarian, Polish, Romanian and Turkish, whose diacritics
  DejaVu covers in full.)
- **4 of 28** are CJK → DroidSansFallback.
- **1 of 28** is Thai → Itim.

Nothing in the shipped set needs Arabic or Hebrew, so the chain is complete for
all 28.

## Sources

| File | Fetched from | Version |
|---|---|---|
| DejaVu family | `github.com/dejavu-fonts/dejavu-fonts` release `version_2_37` | 2.37 |
| LiberationMono-Regular | `github.com/liberationfonts/liberation-fonts` release tarball | 2.1.5 |
| DroidSansFallback | `github.com/aosp-mirror/platform_frameworks_base`, `data/fonts/` | AOSP master |
| Itim-Regular | `github.com/google/fonts`, `ofl/itim/` | Google Fonts |

Full licence text for each is in `LICENSE-*.txt` beside the fonts.  All four
are redistributable in a shipping binary with attribution and no copyleft
obligation on the rest of the tree; Part D's legal pass should carry the four
`LICENSE-*.txt` files into the app's third-party notices.

**Note on `Itim-Regular`.** Google Fonts publishes a `.ttf`, and the Android
startup loader reads that staged `.ttf` directly from the verified overlay
before EngineVGui loads its first scheme. `vr_l10n.cpp` may still write an
optional post-start cache copy named `Itim-Regular.otf`; FreeType identifies the
format from the bytes, so that compatibility filename is harmless, but startup
does not depend on the cache existing.
