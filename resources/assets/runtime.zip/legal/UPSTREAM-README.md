# source-engine-quest

`source-engine-quest` is an experimental standalone Meta Quest and PICO port of
the Source Engine. The engine, OpenXR renderer, input, audio, and game code run
natively on the headset; no PC streaming runtime is used after installation.

Four alternative APK targets retain application ID `com.sourcevrport.hl2vr`.
`full` contains Half-Life 2, Portal, Portal 2, Episode One, Episode Two, and
Half-Life 2: Lost Coast; `hl2EpisodesPortal` contains Half-Life 2, Portal,
Episode One, Episode Two, and Lost Coast; `hl2Episodes` omits both Portal games;
and `pico` packages the full six-game catalog with PICO-specific Android metadata. Each APK contains one launcher and the
separately built arm64 native graphs plus checksum-pinned runtime layers for its
catalog. The launcher selects a graph before starting the engine; the games are
no longer separate Android applications. Players provide the complete retail
depot folders needed by each selected game from legally owned Steam installations.

This is active development. Quest 3 at 72 Hz remains the primary validation
target, and individual catalog games do not all have the same device-test depth.
The PICO target supports Neo3, PICO 4, G3, and PICO Ultra OpenXR interaction
profiles on PICO OS 5.9 or newer; optional optical hands require PICO OS 5.11 or
newer. Device coverage is not yet equal across those models. Games
outside the six-entry catalog are not supported; Lost Coast, its newest entry,
has not yet been tested on a headset.

## Repository layout

The repository is self-contained for building the APK:

```text
source-engine-quest/
├── quest/                    unified Android app, transfer APKs, libraries, wrapper, tools
├── vr_assets/hl2vr/         authorized, checksum-pinned HL2VR runtime subset
├── vr_overlay/              project runtime configuration and UI overlay
├── scripts/                 build/version and asset-maintenance tools
├── game/, engine/, ...      Source Engine and Half-Life 2 game code
└── README.md
```

Generated APK assets, native libraries, build outputs, local SDK settings, signing keys, and retail game data are ignored. They are not source dependencies.

## Install and play

The launcher has an **Updates** panel with optional automatic GitHub update checks
(off by default), manual checks, resumable downloads, and in-place APK installation.
See [launcher updates and release publishing](quest/UPDATES.md).

For the guided path, run `install-sourcevr.cmd` on Windows or
`./install-sourcevr.sh` on macOS/Linux. The interactive installer asks whether
you are targeting Meta Quest or PICO, finds Steam libraries and the latest
matching `SourceVRPort-hl2Episodes-<version>.apk` or
`SourceVRPort-pico-<version>.apk`, checks the default/`steam_legacy` content
branch, lets you choose HL2/Episode One/Episode Two/Lost Coast, installs the APK,
and transfers the required folders to the connected headset. When it finds a
Steam Portal install, it reports which Half-Life 2 lineage that install's `hl2/`
folder holds; it does not copy Portal. For unattended PICO
installs, pass `--headset pico`; `--yes` without `--headset` retains the Quest
default. See
[`installer/README.md`](installer/README.md). The manual process follows.

You need:

- A Meta Quest or PICO headset in Developer Mode. Quest 3 is the currently
  tested device.
- Android SDK Platform Tools (`adb`) and a USB connection.
- A legally owned Steam copy of Half-Life 2.
- Either the default 20th Anniversary content or the archived `steam_legacy`
  content. Matching a desktop save's branch is still the preferred path; the
  narrowly audited exception is described below.
- Free headset storage for the APK, every retail folder required by the selected
  game, and its automatically staged runtime-data layers. There is no preflight
  size scan, so keep at least 1 GiB of additional headroom during first launch
  and updates.

> **Existing Portal / Episode One / Episode Two users:** do not uninstall the old
> `com.sourcevrport.portalvr`, `com.sourcevrport.ep1vr`, or
> `com.sourcevrport.ep2vr` app. First install the
> matching same-ID, same-certificate versionCode 501 transfer update with
> `adb install -r`, run it, and verify its completion receipt. Install the
> unified APK only afterward. Uninstalling the legacy package first deletes the
> only source Android permits the transfer app to read. Follow
> [the save-transfer runbook](quest/SAVE-TRANSFER.md).

### 1. Install the APK

Connect the headset, accept the USB-debugging prompt, and verify the connection.
The debug example below is only for a fresh install or an installation already
signed with the Android debug key:

```sh
adb devices
# Meta Quest
adb install -r /absolute/path/to/app-full-debug.apk
# PICO
adb install -r /absolute/path/to/app-pico-debug.apk
```

If `com.sourcevrport.hl2vr` is already installed as a production release, update
it with the target-correct canonical `app-full-release.apk` for Quest,
`app-pico-release.apk` for PICO, or another audited Quest catalog alternative,
signed by the same historical certificate; a debug APK or a release signed
with a new key cannot update it.
Never uninstall an existing Half-Life 2 package to work around a signer error:
that would delete the old package-owned user tree before the same-ID unified
update can migrate it.

Use `-r` for updates so Android preserves the installed package and its staged
runtime data. The sole production package is `com.sourcevrport.hl2vr` and its
exported entry point is `.LauncherActivity`; the package identifier is
intentionally unchanged so existing Half-Life 2 installations can update in
place. Saves and mutable game writes now live by game directory under
`/sdcard/SourceVRPort/user/`, shared by the unified model rather than tied to a
catalog entry's Android package.

### 2. Prepare the two Steam folders

In Steam:

1. Open **Half-Life 2 > Properties > Betas**.
2. Select the default branch for 20th Anniversary saves, or `steam_legacy` for
   pre-Anniversary saves, then allow Steam to finish downloading the game.
3. Choose **Browse installed files**.
4. Locate the install root containing the sibling `hl2/` and `platform/` directories.

Copy the complete directories for the game to function correctly. The launcher itself does not
enumerate or approve their contents, so it will not catch missing numbered VPK parts or other
damaged retail files before starting the engine.

Save entity state contains map-local inline brush numbers. The port therefore
requires the installed BSP revision to match the save unless that exact,
directional revision pair has a checked migration profile. Currently the only
such profile is the 20th Anniversary `d1_canals_05` revision 3253 save loaded on
the `steam_legacy` revision 3043 map: shared brush references are fingerprinted
against the installed BSP, while the two appended box triggers referenced by
the supported saves are reconstructed from audited geometry and the 14 legacy
visibility separators removed by the Anniversary rebuild are held open. The
third appended model is a non-box convex trigger and remains fail-closed (none
of the audited saves references it). Every other revision mismatch still
reports a clean load error; compatibility is never inferred from revision
ordering.

### 3. Copy `hl2/` and `platform/` to the headset

After installing the APK, stage both folders in public storage, then let the in-headset
importer copy and activate them:

```text
/sdcard/Download/SourceVRPort-HL2-Import/
├── hl2/
│   ├── gameinfo.txt
│   ├── steam.inf
│   ├── cfg/
│   ├── maps/
│   ├── resource/
│   ├── hl2_misc_dir.vpk                 + numbered parts
│   ├── hl2_pak_dir.vpk                  + numbered parts
│   ├── hl2_textures_dir.vpk             + numbered parts
│   ├── hl2_sound_misc_dir.vpk           + numbered parts
│   └── hl2_sound_vo_english_dir.vpk     + numbered parts
└── platform/
    └── platform_misc_dir.vpk            + numbered parts
```

The important detail is that `gameinfo.txt` must be at
`SourceVRPort-HL2-Import/hl2/gameinfo.txt`, not beneath a second nested `hl2/`.

The most reliable transfer method is `adb`. Set `HL2_INSTALL` to the Steam directory containing the two folders:

```sh
export HL2_INSTALL="/absolute/path/to/steamapps/common/Half-Life 2"
export QUEST_STAGE="/sdcard/Download/SourceVRPort-HL2-Import"

adb shell mkdir -p "$QUEST_STAGE"
adb push "$HL2_INSTALL/hl2" "$QUEST_STAGE/"
adb push "$HL2_INSTALL/platform" "$QUEST_STAGE/"
adb shell chmod -R a+rX "$QUEST_STAGE/hl2" "$QUEST_STAGE/platform"
```

In the headset, choose **Import a folder…** and select
`SourceVRPort-HL2-Import`, or select `hl2/` and `platform/` in sequence. The importer
**moves** the selected folders: a folder on the headset's own shared storage (the staging
directory above, or anything else the picker reaches through the device's storage provider) is
renamed into place in one step, with no second copy and no extra free space, so the staging
folder is consumed rather than left behind. A source the app cannot rename directly (another
volume, a cloud provider) is copied as a foreground operation and deleted once the import has
been activated. The importer publishes the moved folders transactionally.
It checks only that the selected depot directories exist and that the primary game directory has
a `gameinfo.txt` bootstrap file; it does not walk the installed tree afterward, compare versions,
inspect VPKs, hash files, or reject zero-byte content. An interrupted import is kept separate
from the currently published folders; relaunching the app retries it from the saved folder
grants, reusing a folder that was already moved. Canceling or failing an import returns moved
folders to where they came from. Existing saves and user configuration are preserved.

The retail pair is published at
`/sdcard/SourceVRPort/common/{hl2,platform}` so every dependent entry in the unified catalog
can share it. Older direct copies at that location are accepted without a content scan; saves,
settings and generated cache files found inside them are preserved into the matching
`/sdcard/SourceVRPort/user/<game-directory>` tree first.
Once the required directories and private bootstrap exist, startup proceeds without a repair or
re-scan gate. Missing or damaged retail files are therefore left for the engine/game to handle.

#### Portal and Lost Coast content

Current Steam Portal (app 400) ships its own `hl2/` folder, and that folder
holds 20th Anniversary Half-Life 2 content, whichever branch your Half-Life 2
uses. It is a partial subset: the `hl2_misc`, `hl2_textures`, `hl2_sound_misc`
and `hl2_sound_vo_english` VPKs, with no `gameinfo.txt`, maps or `hl2_pak`.
Portal is supported on that subset and on a complete `hl2/` from either branch.
When the installed `common/hl2` is Anniversary content, the app mounts its
re-strided shader set for Portal, as it does for Half-Life 2, Episode One,
Episode Two and Lost Coast.

- **Half-Life 2 already imported:** select the `portal/` folder itself, not the
  Steam `Portal` install folder. The importer does not replace an installed
  depot that it merely found inside a parent folder you picked. Selecting
  `portal/` directly still keeps your Half-Life 2 `hl2/` out of the import on
  every build.
- **Portal only:** select the Steam `Portal` install folder, or stage `portal/`,
  `hl2/` and `platform/` under `/sdcard/Download/SourceVRPort-Portal-Import/`.
  Before playing Half-Life 2, Episode One, Episode Two or Lost Coast, import a
  complete Half-Life 2 `hl2/`; those games read its maps, models and `hl2_pak`.
  Portal's partial `hl2/` has no `gameinfo.txt`, so the importer does not count
  it as installed. Picking the Steam `Half-Life 2` install folder for any of
  those games replaces it with the complete `hl2/` and keeps the installed
  `platform/`. Selecting that `hl2/` folder itself also replaces it. Portal
  keeps working on the complete copy. Selecting only `episodic/`, `ep2/` or
  `lostcoast/` itself does not import yet: the importer asks for the complete
  `hl2/` next.
- **Keeping steam_legacy saves:** after importing Portal, select the
  `steam_legacy` Half-Life 2 `hl2/` folder itself. That replaces Portal's
  partial copy with the complete legacy `hl2/`, and Portal keeps working on it.

Lost Coast (app 340) installs a `lostcoast/` folder inside the Half-Life 2 Steam
folder, beside `hl2/` and `platform/`. It needs those two shared folders plus
`lostcoast/`. It takes its shaders from `hl2/`: its `lostcoast_pak` carries none
on either branch, so the app mounts the re-strided set when `common/hl2` is
Anniversary content. Its maps are byte-identical on both branches; its
`gameinfo.txt`, closed captions and localisation files, and three menu and
scheme resources in `lostcoast_pak` differ.

### 4. Launch

```sh
adb shell am force-stop com.sourcevrport.hl2vr
adb shell am start -n com.sourcevrport.hl2vr/.LauncherActivity
```

### Sound balance

**Settings > Sounds** has a master volume and separate sliders for voices,
music, weapons and explosions, ambience, footsteps, and other effects. The
category sliders run from 0% (muted) to 100% (the game's original mix), below
the master volume. Changes apply immediately, including to playing music and
loops; muted playback continues so unmuting resumes at the current position.
Settings save per game when you leave the panel. Sound quality and spatial
audio controls remain on the same page. All six games use these controls on
both Quest and PICO.

### Smooth portal reorientation

In Portal and Portal 2, **Settings > Comfort & Body > Smooth portal
reorientation** eases your view upright after a tilted exit. A wall-to-ceiling
crossing initially leaves you looking down, then smoothly levels the view.
Physical head tracking stays immediate. The option defaults to off; **Portal
reorientation time** adjusts the transition from 0.1 to 2.0 seconds (default
0.5). Console equivalents are `vr_portal_smooth_reorientation 1` and
`vr_portal_reorientation_time 0.5`.

### Optional bHaptics wearables

The Quest build supports bHaptics vests and arm devices in Half-Life 2,
Episode One, and Episode Two. Install bHaptics Player on the headset, grant its
Nearby Devices permission, pair the wearables in Player, then enable **bHaptics
wearables** on the in-game Combat settings page. **Open bHaptics Player** and
`vr_bhaptics_status` provide setup and diagnostics; wearable strength is
independent of Quest controller rumble. See
[`docs/BHAPTICS_QUEST_INTEGRATION.md`](docs/BHAPTICS_QUEST_INTEGRATION.md) for
the runtime contract, SDK provenance, and hardware acceptance checklist.

After the retail launch preflight, the app reads the selected profile's native graph from the
APK and transactionally installs missing non-executable authored/VR data roots into package-owned
storage. Native `.so` blobs remain `STORED` and 16
KiB-aligned inside the signed APK and are mapped directly by bionic; they are not
copied to executable app-data files. The first launch of a profile can take several minutes.
Later launches require only the selected overlay and VR-layer directories; they do not inventory
or hash those extracted roots. Portal additionally performs a bounded structural check of its VPK
index/parts and opening/finale BSP headers before entering VR, so an interrupted retail import
returns to setup with a useful error instead of failing inside the engine.

The complete app-managed layout is:

```text
/sdcard/SourceVRPort/common/
├── hl2/              HL2, Portal, Episode One, Episode Two and Lost Coast dependency
├── platform/         Source 2007 platform dependency for those five games
├── portal/           Portal retail content
├── episodic/         Episode One content; also required by Episode Two
├── ep2/              Episode Two retail content
├── lostcoast/        Lost Coast retail content
├── update/           Portal 2 highest-priority content
├── portal2_dlc2/     Portal 2 DLC2 content
├── portal2_dlc1/     Portal 2 DLC1 content
├── portal2/          Portal 2 base content
└── portal2_platform/ Portal 2 platform content, imported from AppID 620 platform/

/sdcard/SourceVRPort/user/
├── hl2/              HL2 saves, configuration and generated writes
├── portal/           Portal saves, configuration and generated writes
├── portal2/          Portal 2 saves, configuration and generated writes
├── episodic/         Episode One saves, configuration and generated writes
├── ep2/              Episode Two saves, configuration and generated writes
└── lostcoast/        Lost Coast saves, configuration and generated writes

/sdcard/SourceVRPort/.userdata-transfer/
├── hl2.receipt       verified migration of the old HL2-ID user tree
├── portal.receipt    verified Portal transfer
├── ep1.receipt       verified Episode One transfer
└── ep2.receipt       verified Episode Two transfer

/sdcard/Android/data/com.sourcevrport.hl2vr/files/
├── sourcevr_runtime_data/v1/overlay/  extracted authored overlays by profile
├── sourcevr_runtime_data/v1/vr/       extracted VR data layers
├── diagnostics/      created automatically
└── user/hl2/         retained source from a pre-unified HL2 update
```

Do not merge HL2VR files into `hl2/`, create `vr_content/`, or run a separate mod-harvesting step. Those were development-only workflows and are obsolete.

Useful startup logs:

```sh
adb logcat -s 'SRCENG:*' 'SRCENG-ASSETS:*' 'SRCENG-IMPORT:*' \
  'SRCENG-DEVSTATE:*' 'HL2VR-Main:*' 'HL2VR-XR:*'
```

## Build the APK

The build is currently tested on macOS. The scripts use repository-relative paths and discover the installed NDK host toolchain, but Linux and Windows hosts have not received the same end-to-end validation.

Install:

- Git and this repository's recursive submodules.
- Python 3.
- Android SDK Platform 34, Build Tools, and Platform Tools.
- Android NDK r27c, version `27.2.12479018`.
- JDK or Android Studio JBR 21. Android source compatibility is Java 17.
- Bash and ordinary Unix command-line tools.

The checked-in wrapper supplies Gradle 8.10.2; no system Gradle is needed.

### Unified native and asset inputs

Run from the repository root:

```sh
export SOURCE_ENGINE_QUEST_ROOT="$PWD"
export ANDROID_SDK_ROOT="$HOME/Library/Android/sdk"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export ANDROID_NDK_HOME="$ANDROID_SDK_ROOT/ndk/27.2.12479018"
export JAVA_HOME="/path/to/jdk-or-jbr-21"

git submodule update --init --recursive

# Generate one matching Java/native build stamp.
python3 scripts/gen_version.py

# Portal 2's graph needs the pinned decoder-only FFmpeg prefix.
./quest/build_portal2_ffmpeg.sh

# Configure and build one isolated Waf tree for every catalog profile.
./waf configure -o build-hl2 -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=hl2
./waf configure -o build-portal -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=portal
./waf configure -o build-portal2 -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=portal2
./waf configure -o build-ep1 -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=episodic
./waf configure -o build-ep2 -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=ep2
./waf configure -o build-lostcoast -T release --android=aarch64,clang,29 --togles --disable-warns --build-games=lostcoast
( cd build-hl2 && ../waf build )
( cd build-portal && ../waf build )
( cd build-portal2 && ../waf build )
( cd build-ep1 && ../waf build )
( cd build-ep2 && ../waf build )
( cd build-lostcoast && ../waf build )

# Stage all six native/overlay inputs.
SOURCEVR_WAF_BUILD_DIR="$PWD/build-hl2" ./quest/stage_jnilibs.sh hl2
SOURCEVR_WAF_BUILD_DIR="$PWD/build-portal" ./quest/stage_jnilibs.sh portal
SOURCEVR_WAF_BUILD_DIR="$PWD/build-portal2" ./quest/stage_jnilibs.sh portal2
SOURCEVR_WAF_BUILD_DIR="$PWD/build-ep1" ./quest/stage_jnilibs.sh ep1
SOURCEVR_WAF_BUILD_DIR="$PWD/build-ep2" ./quest/stage_jnilibs.sh ep2
SOURCEVR_WAF_BUILD_DIR="$PWD/build-lostcoast" ./quest/stage_jnilibs.sh lostcoast
for profile in hl2 portal portal2 ep1 ep2 lostcoast; do
  ./quest/stage_assets.sh "$profile"
done

# Deduplicate, strip, validate and manifest the six runtime graphs.
python3 quest/prepare_unified_assets.py \
  --output quest/app/build/generated/sourcevrAssets/full/sourcevr
python3 quest/prepare_unified_assets.py \
  --output quest/app/build/generated/sourcevrAssets/full/sourcevr --check

# The smaller alternative excludes both Portal graphs and payloads.
python3 quest/prepare_unified_assets.py \
  --include-profile hl2 --include-profile ep1 --include-profile ep2 \
  --include-profile lostcoast \
  --output quest/app/build/generated/sourcevrAssets/hl2Episodes/sourcevr

# The Portal 1 alternative excludes only the Portal 2 graph and payload.
python3 quest/prepare_unified_assets.py \
  --include-profile hl2 --include-profile portal \
  --include-profile ep1 --include-profile ep2 --include-profile lostcoast \
  --output quest/app/build/generated/sourcevrAssets/hl2EpisodesPortal/sourcevr

# Four targets, all using the same HL2 application ID. PICO reuses the full store.
( cd quest && ./gradlew :app:assembleFullDebug \
                         :app:assembleHl2EpisodesDebug \
                         :app:assembleHl2EpisodesPortalDebug \
                         :app:assemblePicoDebug )
```

The APK is written to:

```text
quest/app/build/outputs/apk/full/debug/app-full-debug.apk
quest/app/build/outputs/apk/hl2Episodes/debug/app-hl2Episodes-debug.apk
quest/app/build/outputs/apk/hl2EpisodesPortal/debug/app-hl2EpisodesPortal-debug.apk
quest/app/build/outputs/apk/pico/debug/app-pico-debug.apk
```

The order matters: generate one version, build and stage all six Waf profiles,
run `prepare_unified_assets.py`, then build the one Android app. The preparation
step writes content-addressed native assets under
`sourcevr/v1/native/blobs/<sha256>/<soname>.so` with dependency-first profile
manifests. Post-strip libraries that differ only in the descriptor of a valid
GNU build-ID note share the first catalog profile's intact binary; all other
ELF bytes must compare exactly. AGP keeps `.so` assets ZIP `STORED`; the canonical Gradle package
task then runs an explicit `zipalign -P 16` pass and re-signs each canonical
catalog APK so bionic can map the selected graph
directly from the signed APK. The build fails rather than emitting an
installable-looking, misaligned graph.
The profile-neutral JNI bootstrap is the only ordinary native library.

The Gradle `:app:prepareFullUnifiedAssets` and
`:app:prepareHl2EpisodesUnifiedAssets` and
`:app:prepareHl2EpisodesPortalUnifiedAssets` dependencies rerun the matching
preparation automatically. The explicit invocation above is retained as an auditable gate
between staged profile inputs and APK packaging. See
[the complete target build contract](quest/BUILD-TARGETS.md).

For ordinary incremental builds, rerun `gen_version.py`, each affected Waf
build, that profile's staging scripts, unified preparation, and Gradle. Re-run
Waf `configure` when the NDK or configuration flags change.

The app is arm64-v8a-only, targets Android API 34, and has a minimum API of 29.

### Signed release build

Release builds require `quest/keystore/release-signing.properties`. The
production upgrade/migration set must use the historical signing identity whose
certificate is pinned by the combined APK audit; an arbitrary new key creates a
fresh-install lineage and cannot update existing HL2, Portal, EP1, or EP2 packages.
Follow [the signing notes](quest/keystore/README-DO-NOT-COMMIT.md), and never
commit the keystore, properties file, or passwords. Gradle refuses to fall back
to a debug key for a release build.

After native staging and the catalog preparation steps:

```sh
( cd "$SOURCE_ENGINE_QUEST_ROOT/quest" && \
  ./gradlew :app:assembleFullRelease :app:assembleHl2EpisodesRelease \
            :app:assembleHl2EpisodesPortalRelease \
            :app:assemblePicoRelease \
            :save-transfer:assemblePortalRelease \
            :save-transfer:assembleEp1Release \
            :save-transfer:assembleEp2Release )
```

The outputs are `quest/app/build/outputs/apk/full/release/app-full-release.apk`,
`quest/app/build/outputs/apk/hl2Episodes/release/app-hl2Episodes-release.apk`,
`quest/app/build/outputs/apk/hl2EpisodesPortal/release/app-hl2EpisodesPortal-release.apk`,
and `quest/app/build/outputs/apk/pico/release/app-pico-release.apk`.
All use the sole application ID `com.sourcevrport.hl2vr`; they are alternative
updates, not side-by-side applications.

Audit the complete signed release set before installing or distributing it:

```sh
python3 quest/audit_unified_apks.py \
  --main quest/app/build/outputs/apk/full/release/app-full-release.apk \
  --portal quest/save-transfer/build/outputs/apk/portal/release/save-transfer-portal-release.apk \
  --ep1 quest/save-transfer/build/outputs/apk/ep1/release/save-transfer-ep1-release.apk \
  --ep2 quest/save-transfer/build/outputs/apk/ep2/release/save-transfer-ep2-release.apk
```

Audit `hl2Episodes` with `--catalog hl2episodes` and omit `--portal`. Audit the
Portal 1 target with `--catalog hl2episodesportal` and all three transfer APKs.
Audit the PICO target with `--headset pico --catalog full` and the
`app-pico-release.apk` path.

The combined gate pins IDs, version code, signer, signature schemes, OpenXR
visibility, launcher/export rules, all graph/blob hashes and markers, and every
native asset's `STORED` 16 KiB-aligned ZIP offset. The legacy per-profile
`quest/audit_apk.sh` does not understand the unified graph format.

## Bundled HL2VR assets

`vr_assets/hl2vr/content/` contains the tested portable runtime-data layer from
Half-Life 2: VR Mod. It includes VR models and materials, map patches and
navigation graphs, weapon/audio scripts, all 57 HL2VR WAV files, fonts, haptics,
and supporting resources. Do not duplicate its file/byte census in build
instructions: `vr_assets/hl2vr/MANIFEST.sha256` and the exact gates in
`quest/stage_vr_assets.sh` are the current authorities.

The bundle deliberately excludes Windows binaries, desktop shader/configuration data, `gameinfo.txt`, the raw VPK after its navigation graphs are unpacked, desktop-only `.dx80.vtx`/`.sw.vtx` files, the unused 67 MiB `materials/models/player/player.vtf`, and the desktop `resource/gamemenu.res` that conflicts with Quest's runtime menu. Paths and material references are normalized for Android's case-sensitive filesystem.

Builds consume only the committed bundle and [checksum allowlist](vr_assets/hl2vr/MANIFEST.sha256). [SOURCE.md](vr_assets/hl2vr/SOURCE.md) records its exact source and transformations, [AUTHORIZATION.md](vr_assets/hl2vr/AUTHORIZATION.md) records the permission representation, and [CREDITS.txt](vr_assets/hl2vr/CREDITS.txt) preserves upstream attribution. `scripts/import_hl2vr_assets.py` is a maintainer-only reproducibility tool; players and ordinary builders do not run it.

## Updates, backups, and troubleshooting

- Always update with `adb install -r` and the same signing identity. Android rejects an update signed by a different key.
- Before replacing a legacy Portal/EP1/EP2 app, follow [the transfer order](quest/SAVE-TRANSFER.md). The transfer release must use versionCode 501, the exact legacy application ID, and certificate SHA-256 `532cdaaf12deae0eb42704394b603c66c035211ad973e4cdf17cbb78000776c3`. Debug transfer APKs cannot update release installs.
- Uninstalling the unified app deletes its package-owned diagnostics and staged runtime data. Shared retail depots under `/sdcard/SourceVRPort/common` and shared mutable data under `/sdcard/SourceVRPort/user` are ordinary public storage and are not removed automatically.
- Back up saves before uninstalling:

  ```sh
  adb pull /sdcard/SourceVRPort/user ./sourcevr-user-backup
  ```

- If the importer opens, grant shared-storage access and provide the depot folders requested for
  the selected game. Portal's bounded preflight reports missing/truncated core payloads; it does
  not replace the exact hash-based developer campaign-content audit.
- If a folder import was interrupted, reopen **Import from folder**. The persisted folder grants and foreground journal let the current build retry safely; the previous installed content remains active until promotion succeeds.
- If bundled-asset installation fails, make additional free space and relaunch. The staging transaction is retried and does not mount a partial tree.
- `INSTALL_FAILED_UPDATE_INCOMPATIBLE` means the installed build uses another
  signing key. Do not uninstall an existing HL2, Portal, EP1, or EP2 package as a
  workaround: that destroys the package-owned source the migration was meant to
  rescue.
- The automated legacy transfer covers Portal, EP1, and EP2 versionCode-500 packages. There is no retired standalone Portal 2 transfer flavor; make an external backup before uninstalling any unrecognized legacy package.

## Legal and provenance

`source-engine-quest` is an unofficial community project and is not affiliated with or endorsed by Valve, Meta, or the Half-Life 2: VR Mod project. Half-Life, Source, Steam, and related names and assets belong to their respective owners.

The checked-in EP1/EP2 layers are approved for public APK distribution only at
the exact paths and hashes recorded by their `MANIFEST.sha256` and
`AUTHORIZATION.md` files, including the reviewed map-class inputs. Any payload
change requires a new provenance/rights review and authorization update.

The APK does not include the wholesale retail depots required to play any
catalog game. Users must own each selected game and import those depots. The
bundled Half-Life 2: VR Mod subsets and reviewed map-class inputs are included
under their exact authorization records; source manifests and contributor
credits are shipped with the APK.

This fork descends from [nillerusr/source-engine](https://github.com/nillerusr/source-engine). The upstream provenance notice is intentionally preserved: **the source code is based on the TF2 2018 leak; do not use it for commercial purposes.** Review [LICENSE](LICENSE), [thirdpartylegalnotices.txt](thirdpartylegalnotices.txt), and [UPSTREAM_PIN.md](UPSTREAM_PIN.md) before distributing source or binaries.
