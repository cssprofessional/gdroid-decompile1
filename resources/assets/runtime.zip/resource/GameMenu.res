"GameMenu"
{
    "1" { "label" "Resume game" "command" "ResumeGame" "OnlyInGame" "1" }
    "2" { "label" "Start a new game" "command" "OpenCreateMultiplayerGameDialog" }
    "3" { "label" "Join a server" "command" "OpenJoinServerDialog" }
    "4" { "label" "Options" "command" "OpenOptionsDialog" }
    "5" { "label" "Console" "command" "OpenConsole" }
    "6" { "label" "Disconnect" "command" "Disconnect" "OnlyInGame" "1" }
    "7" { "label" "Quit to launcher" "command" "Quit" }
}
