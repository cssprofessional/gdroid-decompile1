"GameMenu"
{
    "1" { "label" "Resume Game" "command" "ResumeGame" "FlatMenuPhrase" "resume_game" "OnlyInGame" "1" }
    "2" { "label" "Start New Game" "command" "OpenCreateMultiplayerGameDialog" "FlatMenuPhrase" "new_game" "FlatMenuGap" "1" }
    "3" { "label" "Find Multiplayer Game" "command" "OpenJoinServerDialog" "FlatMenuPhrase" "find_mp_game" }
    "4" { "label" "Addons" "command" "FlatOpenAddons" "FlatMenuPhrase" "addons" "FlatMenuGap" "1" }
    "5" { "label" "Dupes" "command" "FlatOpenDupes" "FlatMenuPhrase" "dupes" }
    "6" { "label" "Saves" "command" "FlatOpenSaves" "FlatMenuPhrase" "saves" }
    "7" { "label" "Demos" "command" "FlatOpenDemos" "FlatMenuPhrase" "demos" }
    "8" { "label" "Options" "command" "OpenOptionsDialog" "FlatMenuPhrase" "options" "FlatMenuGap" "1" }
    "9" { "label" "Disconnect" "command" "Disconnect" "FlatMenuPhrase" "disconnect" "OnlyInGame" "1" "FlatMenuGap" "1" }
    "10" { "label" "Quit" "command" "Quit" "FlatMenuPhrase" "quit" "FlatMenuGap" "1" }
}
